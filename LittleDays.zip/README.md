# Little Days — Android personal planner and CPD journal

## What this is
A native Java Android application for Android 13 and newer. No account, server,
analytics, advertising, or internet permission. A pastel gingham background,
rounded cards, hand-drawn bunny and pastel icons are original to this project.
The bundled rounded typeface uses the Android system font rather than a downloaded font.
The supplied reference images are inspiration only and are not bundled.

This project has NOT been compiled or device-tested in the generation environment.
GitHub Actions performs the first actual Android build. Use the build log to diagnose
any compile errors. Test with sample data and restore a backup before trusting important CPD data.

## Phone-only setup
1. Upload LittleDays.zip AS A ZIP to your GitHub repository root. Do not extract it.
   Keep the exact filename (no '(1)' suffix).
2. On the repository Code page, choose Add file > Create new file.
3. Name the file exactly: .github/workflows/build-apk.yml
4. Paste the contents of the separately provided build-apk.yml, then commit.
   Uploading build-apk.yml to the repository root does NOT register a workflow.
5. Open Actions > Build Little Days APK > Run workflow. A push may already have
   started a build; either wait for that or start a manual run.
6. Wait for the green tick. Open the run and find Artifacts > Little-Days-APK.
7. Download and extract that artifact ZIP on your phone. Open app-debug.apk and
   approve Android's install-from-this-source prompt for your browser/file manager.
   Do not disable security checks globally.

If GitHub's mobile layout hides Add file, use Chrome's Desktop site option.
An empty new repository may first offer a Create a new file / uploading an existing file link.
If the run fails, expand the red build step and copy the first compiler error and nearby lines.

## Future updates and signing — IMPORTANT
Replace LittleDays.zip with a complete updated ZIP. The workflow stays in place.
The project includes a unique personal-development signing key at signing/personal.p12.
Keep a safe copy of this original project ZIP. FUTURE VERSIONS MUST REUSE THIS KEY,
application ID uk.co.littledays, and increase versionCode. Otherwise Android may reject
an in-place update. Do not uninstall to work around a signing error without a backup.
This is a development APK, not a production/Play Store distribution setup.
The key and its development password are in the project: anyone who can read them
could sign an app as this development identity. Use a PRIVATE repository, do not
publish the key or distribute this signing identity. Production distribution needs
separate private signing-key management. Do not upload journals or backups to GitHub.

## Feature guide
Home:
- Work Schedule opens the themed month calendar. Choose Work / Day Off / Holiday,
  then tap multiple dates. Every change saves immediately. Clear a day unsets it.
- The horizontal strip displays approximately six dates, from 30 days ago to a year
  ahead, positioned at today on opening. The month calendar can navigate further.
- Today's outline and three separately coloured schedule icons distinguish dates.
- CPD opens today's journal directly.
- Daily Stuff: Add opens a task input. Tap a task to tick/untick. New tasks append.
  Hold a row and drag onto another row to move it there. For long lists, move in stages
  after scrolling. Swipe right to highlight and confirm removal. Cancel keeps it.

CPD:
- Text saves as you type. Date header opens a separate calendar; dots highlight entries.
- Previous / Today / Next buttons also navigate. Empty dates are editable.
- Attach images uses Android's document picker; select one or multiple images if the
  provider supports it. Cloud providers may need a connection to fetch originals.
- Photos are copied into private app storage and converted to JPEG (up to 2600px
  on the longest side, quality 90). Orientation is corrected where EXIF is available.
  This is not an original-resolution photo archive; animated images become stills
  and transparency is not retained. Keep originals elsewhere if needed.
- Tap a thumbnail for a full-screen viewer, pinch zoom and pan. Double-tap resets.
  Close returns to CPD. Delete asks for confirmation and only removes the app copy.
- Export opens a From / To selection panel with themed calendars for both endpoints.
  Save PDF opens Android's save-location picker. The range is inclusive.
- PDF contains non-empty entries in chronological order, text with automatic page
  breaks, and photos. Every entry starts on a new page. Empty dates are skipped.
  Text uses Android's PDF font support; unusual emoji/scripts may not render perfectly.

Settings:
- Checkbox reset defaults ON. Task names/order remain. Uses phone-local date.
  While the app is open it checks every 30 seconds; if closed, resets on next open.
  OFF keeps the ticks until manually changed.
- Backup exports a ZIP containing all app data and photo copies to your chosen location.
- Restore validates a ZIP and asks before replacing local data. Restore is replacement,
  not merge. Backups from this app only; 2 GB / 20,000 files safety limits.
- Exports are not encrypted. Device app sandbox protects local app data; this is
  not a PIN/biometric vault. Uninstallation clears local data. Manual backups matter.
- No Android system auto-backup is enabled; use the explicit Backup button.

## CPD privacy
Do not record patient-identifiable details or identifiable clinical photos. Exporting
professional records to cloud folders can have workplace information-governance implications.
This app stores reflections; it does not certify CPD hours or compliance with a regulator.

## Build configuration
Android Gradle Plugin 8.7.3, Gradle 8.9, Java 17; compile SDK 35, target SDK 34,
minimum SDK 33. Targeting an older SDK is intentional for this personal sideload build,
not a claim of current Play Store publication eligibility. No third-party runtime dependencies.
GitHub Actions downloads the build tools; no Gradle wrapper binary is necessary for this workflow.
For a local build, install SDK 35, Java 17 and Gradle 8.9, then run: gradle assembleDebug

## Suggested first-run checks
1. Set all schedule modes across a month boundary, close/reopen the app, verify.
2. Create journals on two dates, add portrait/landscape photos, zoom and delete one.
3. Export a multi-date PDF and open it in a PDF reader; inspect text and images.
4. Add/tick/reorder/remove tasks and cancel a deletion to verify it is kept.
5. Save a backup, alter sample data, restore and verify every feature and photograph.
6. Verify daily reset after the next real date change, including reset OFF.
7. Try larger Android font settings and your usual keyboard for layout comfort.
